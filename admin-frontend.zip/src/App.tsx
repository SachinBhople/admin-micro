import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.scss'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { Provider } from 'react-redux'
import ErrorBoundary from './pages/ErrorBoundary'
import Home from './pages/Home'
import Orders from './pages/Orders'
import Users from './pages/Users'
import AddProduct from './components/AddProduct'
import ReturnRequested from './components/ReturnRequested'
import UserDetails from './components/UserDetails'
import Navbar from './components/Navbar'
import reduxStore from './redux/store'
import Product from './pages/Products'

const App = () => (
  <>
    <ErrorBoundary>
      <Navbar />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/product' element={<Product />} />
        <Route path='/order' element={<Orders />} />
        <Route path='/user' element={<Users />} />
        <Route path='/add-product' element={<AddProduct />} />
        <Route path='/return-request' element={<ReturnRequested />} />
        <Route path='/userDetails/:id' element={<UserDetails />} />
        <Route path='*' element={<h1>Page Not Found</h1>} />
      </Routes>
    </ErrorBoundary>
  </>
)
const rootElement = document.getElementById('app')
if (!rootElement) throw new Error('Failed to find the root element')

const root = ReactDOM.createRoot(rootElement as HTMLElement)

root.render(<React.StrictMode>
  <BrowserRouter>
    <Provider store={reduxStore}>
      <App />
    </Provider>
  </BrowserRouter>
</React.StrictMode >)